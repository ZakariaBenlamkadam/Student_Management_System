package com.ensah;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Contact {

	private String fax;
	private String phoneNumber;
	private String email;
	private String adress;

	public Contact() {

	}

	public Contact(String fax, String phoneNumber, String email, String adress) {
		this.fax = fax;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.adress = adress;
	}

	// Sans utiliser les expression régulières
	public boolean isEmailValideWithoutRegEx() {

		// On supprime les espaces à la fin et au début
		String lEmail = email.trim();

		// On divise avec le séparateur @
		String[] mailTokens = lEmail.split("@");

		// on doit avoir deux sous chaines non vides apres séparation avec @
		if (mailTokens.length != 2 || mailTokens[0].isEmpty() || mailTokens[1].isEmpty())
			return false;

		// on sépare avec '.'
		String[] domainTokens = mailTokens[1].split("\\.");

		// on doit avoir deux sous chaines non vides
		if (domainTokens.length != 2 || mailTokens[0].isEmpty() || mailTokens[1].isEmpty())
			return false;

		return true;
	}

	// Avec utilisation des expressions régulières
	public boolean isEmailValide() {


		String regEx = "^\\w+@\\w+\\.\\w+$";

		return email.matches(regEx);
	}



	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contact other = (Contact) obj;
		if (adress == null) {
			if (other.adress != null)
				return false;
		} else if (!adress.equals(other.adress))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (fax == null) {
			if (other.fax != null)
				return false;
		} else if (!fax.equals(other.fax))
			return false;
		if (phoneNumber == null) {
			if (other.phoneNumber != null)
				return false;
		} else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		return true;
	}

	public void showContact() {
		System.out.println(
				"[fax=" + fax + ", phoneNumber=" + phoneNumber + ", email=" + email + ", adress=" + adress + "]");
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}
}
