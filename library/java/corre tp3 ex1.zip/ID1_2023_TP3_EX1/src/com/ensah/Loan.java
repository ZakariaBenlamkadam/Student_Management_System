package com.ensah;

import java.util.Date;

public class Loan {
	private int id;
	private Date dateStart;
	private Date dateEnd;
	public Book book;



	public Loan(int id, Date dateStart, Date dateEnd, Book book) {
		this.id = id;
		this.dateStart = dateStart;
		this.dateEnd = dateEnd;
		this.book = book;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDateStart() {
		return dateStart;
	}

	public void setDateStart(Date dateStart) {
		this.dateStart = dateStart;
	}

	public Date getDateEnd() {
		return dateEnd;
	}

	public void setDateEnd(Date dateEnd) {
		this.dateEnd = dateEnd;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

}
