package com.ensah;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PrincipalProg {
	public static void main(String[] args) {

		// Création de 2 auteurs avec le constructeur sans arguments
		Author auth1 = new Author();
		Author auth2 = new Author();

		// et Initialisation des attributs des auteurs avec les setters
		auth1.setFisrtName("Dan");
		auth1.setLastName("Jurafsky");
		auth2.setFisrtName("James");
		auth2.setLastName("Martin");
		
		// Création de deux auteurs avec le constructeur qui initialise les attributs
		Author auth3 = new Author("Claude", "Delanoy");
		Author auth4 = new Author("Pascal", "Reque");

		// Création de 3 livres avec des méthodes différente
		
		Book b1 = new Book();
		// Initialiser quelques attributs avec les setters
		b1.setTitle("Speech and Language Processing");
		b1.setId(125);
		b1.setIsbn("INBB12589");
		b1.setKind("NLP");
		// On défini les auteurs de ce livre
		b1.addAuthor(auth1);
		b1.addAuthor(auth2);
		
		//Création d'un livre et intialisation avec un constructeur et un setter
		Book b2 = new Book(122, "Programmer en Java", 400, 200, "A15888", "JAVA");
		ArrayList<Author> auteursb2 = new ArrayList<>();
		auteursb2.add(auth3);
		b2.setAuthors(auteursb2);
		
		//Création d'un livre avec intialisation de tous les attributs par le constructeur
		ArrayList<Author> auteurs = new ArrayList<>();
		auteurs.add(auth4);
		Book b3 = new Book(125, "UML par la pratique", 250, 150, "Ad15888", "UML");
		
		
		// Création de deux étudiants

		Student std1 = new Student("Karami", "Ali", 20, "AA123456",
				new Contact("025666", "0602555", "dsdsqd@dqsdqsd.fr", "Tanger Beni Makda"));

		Student std2 = new Student("Eraji", "Karam", 21, "AA145456",
				new Contact("06528", "025874", "aaxd@dqsdqsd.fr", "Al Hoceima centre"));

		//Vérifier les données des étudiants
		if(std1.isCinValide()){
			System.out.println("CIN valide");
		}
		else{
			System.out.println("CIN invalide");
		}

		if(std1.getContact().isEmailValide()){
			System.out.println("Email valide");
		}
		else{
			System.out.println("Email invalide");
		}


		//L'étudiant std1 emprunte des livres
		std1.addLoan(new Loan(152, new Date(), null, b3));
		std1.addLoan(new Loan(158, new Date(), null, b2));

	
		
		//Afficher les empruts de l'étudiant std1
		List<Loan> loans =  std1.getAllLoans();
		for(Loan it : loans) {
			System.out.println("Livre emprunté : ID:"+it.getBook().getId()+" Titre :"+ it.getBook().getTitle());
		}
		
		
		
	
	}
}
