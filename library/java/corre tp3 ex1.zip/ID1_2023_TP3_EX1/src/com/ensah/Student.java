package com.ensah;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Represente un étudiant
 * 
 * @author Boudaa
 *
 */
public class Student {

	private String nom;
	private String prenom;
	private int age;
	private String cin;

	public Contact contact;
	public List<Loan> loans = new ArrayList<Loan>();

	public Student() {

	}

	public Student(String nom, String prenom, int age, String cin, Contact contact) {
		this.nom = nom;
		this.prenom = prenom;
		this.age = age;
		this.cin = cin;
		this.contact = contact;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (age != other.age)
			return false;
		if (cin == null) {
			if (other.cin != null)
				return false;
		} else if (!cin.equals(other.cin))
			return false;
		if (contact == null) {
			if (other.contact != null)
				return false;
		} else if (!contact.equals(other.contact))
			return false;
		if (nom == null) {
			if (other.nom != null)
				return false;
		} else if (!nom.equals(other.nom))
			return false;
		if (prenom == null) {
			if (other.prenom != null)
				return false;
		} else if (!prenom.equals(other.prenom))
			return false;
		return true;
	}

	public void showDetails() {
		System.out.println(
				"Information de l'étudiant [nom=" + nom + ", prénom=" + prenom + ", age=" + age + ", cin=" + cin);
		System.out.println("Information de son contact : ");
		contact.showContact();
	}


	/**
	 * permet de vérifier un cide CIN
	 *
	 * @return
	 */
	public boolean isCinValideWithoutRegEx() {


		if (cin.charAt(0) < 'A' || cin.charAt(0) > 'Z')
			return false;

		boolean ok = false;
		int indiceDebutChiffres = 1;
		if (((cin.charAt(1) >= 'A' || cin.charAt(1) <= 'Z') && cin.length() == 8)
				|| ((cin.charAt(1) >= '0' || cin.charAt(1) <= '9') && cin.length() == 7)) {
			ok = true;
			if(cin.length() == 8) {
				indiceDebutChiffres = 2;
			}

		}
		if(ok) {
			for (int i = indiceDebutChiffres; i < cin.length(); i++) {
				if (cin.charAt(i) < '0' || cin.charAt(i) > '9') {
					ok = false;
					break;
				}

			}
		}


		return ok;

	}

	public boolean isCinValide() {

		Pattern cinPattern = Pattern.compile("^([A-Z]\\d{6})|([A-Z]{2}\\d{6})$");

		// créer les objets Matcher associés
		Matcher m = cinPattern.matcher(cin);

		if (m.matches()) {
			return true;
		}

		//NOTE : On peut aussi utiliser la méthode matches de la classe String

		return false;

	}
	public void addLoan(Loan pLoan) {

		loans.add(pLoan);

	}

	public Loan findLoanById(int id) {

		for (Loan it : loans) {

			if (it.getId() == id)
				return it;
		}
		return null;
	}

	public boolean deleteLoan(int id) {
		Loan lLoan = findLoanById(id);
		if (lLoan != null) {
			loans.remove(lLoan);
			return true;
		}
		return false;
	}

	public List<Loan> getAllLoans() {
		return loans;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCin() {
		return cin;
	}

	public void setCin(String cin) {
		this.cin = cin;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public List<Loan> getLoans() {
		return loans;
	}

	public void setLoans(List<Loan> loans) {
		this.loans = loans;
	}
}
