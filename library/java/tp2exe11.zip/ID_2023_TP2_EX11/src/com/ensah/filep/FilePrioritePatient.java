package com.ensah.filep;

import com.ensah.list.Node;
import com.ensah.list.SingleLinkedList;

public class FilePrioritePatient {

    SingleLinkedList[ ] filep = new SingleLinkedList [3] ;

    public FilePrioritePatient() {
        //Création des 3 listes
        filep[0] =  new SingleLinkedList();
        filep[1] =  new SingleLinkedList();
        filep[2] =  new SingleLinkedList();
    }
    public boolean insererPatient (Patient p){
        if(p.getPriorite()>3 || p.getPriorite()<0)
            return  false;
        filep[p.getPriorite()-1].addElement(p);
        return true;
    }
    public  Patient enleverPatientMax ( ) {
        Patient p;
        if(filep[2]!=null && !filep[2].isEmpty()) {
             p = (Patient) filep[2].getFirstElement().getValue();
            filep[2].deleteElement(0);
        }
        else if(filep[1]!=null && !filep[1].isEmpty()) {
            p = (Patient) filep[1].getFirstElement().getValue();
            filep[1].deleteElement(0);
        }
        else  {
            p = (Patient) filep[0].getFirstElement().getValue();
            filep[0].deleteElement(0);
        }

        return p;

    }
   public void affichePatients ( ) {
       System.out.println("******** Priorite 3 *****");
       filep[2].display();
       System.out.println("******** Priorite 2 *****");
       filep[1].display();
       System.out.println("******** Priorite 1 *****");
       filep[0].display();
   }
}
