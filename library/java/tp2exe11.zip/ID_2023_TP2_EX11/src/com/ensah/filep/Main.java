package com.ensah.filep;

public class Main {
    public static void main(String[] args) {

        Patient p1 = new Patient( "Test1", "dsqd",22,  1);
        Patient p2 = new Patient("Test2", "Sadid", 2, 2);
        Patient p3 = new Patient( "Test3", "dsqd", 2, 2);
        Patient p4 = new Patient( "Test4", "dsq", 3, 3);

        FilePrioritePatient f = new FilePrioritePatient();

        f.insererPatient(p1);
        f.insererPatient(p2);
        f.insererPatient(p3);
        f.insererPatient(p4);

        f.affichePatients();

        System.out.println("//////");
        f.enleverPatientMax();
        f.affichePatients();
        System.out.println("//////");
        f.enleverPatientMax();
        f.affichePatients();
        System.out.println("//////");
        f.enleverPatientMax();
        f.affichePatients();
        System.out.println("//////");
        f.enleverPatientMax();
        f.affichePatients();

    }
}