package com.ensah.filep;

public class Patient {
    private String nom;
    private String prenom;
    private int numSecuriteSoc;
    private int priorite;

    public Patient(String nom, String prenom, int numSecuriteSoc, int priorite) {
        this.nom = nom;
        this.prenom = prenom;
        this.numSecuriteSoc = numSecuriteSoc;
        this.priorite = priorite;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", numSecuriteSoc=" + numSecuriteSoc +
                ", priorite=" + priorite +
                '}';
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getNumSecuriteSoc() {
        return numSecuriteSoc;
    }

    public void setNumSecuriteSoc(int numSecuriteSoc) {
        this.numSecuriteSoc = numSecuriteSoc;
    }

    public int getPriorite() {
        return priorite;
    }

    public void setPriorite(int priorite) {
        this.priorite = priorite;
    }
}
