package com.ensah.list;
public class Node {

    private Object value;
    private Node next;

    public Node (Object pValue, Node pNext){
        value = pValue;
        next = pNext;
    }

    public Node (Object pValue){
        value = pValue;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }
}
