package com.ensah.list;

public class Point {

	private double x;

	private double y;

	public Point(double px, double py) {
		x = px;
		y = py;
	}

	public boolean equals(Object p) {
		if (p == this) {
			return true;
		}
		if (p == null) {
			return false;
		}
		if (p.getClass() != this.getClass()) {
			return false;
		}

		Point pt = (Point) p;

		return pt.x == x && pt.y == y;
	}

	public void deplacer(double dx, double dy) {
		x += dx;
		y += dy;
	}

	public double distance(Point p) {

		return Math.sqrt(Math.pow(x - p.x, 2) + Math.pow(y - p.y, 2));
	}

	// Autre méthode
	public static double distance2(Point p1, Point p2) {

		return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
	
	public String toString() {
		return "("+x+","+y+")";
	}
}
