package com.ensah.list;

/**
 * Classe qui permet d'implémenter une liste simplement chaînee
 *
 * @author Tarik BOUDAA
 */
public class SingleLinkedList {

    /**
     * Référence sur le début de la liste
     */
    private Node begin = null;
    /**
     * Référence le dernier élément de la liste
     */
    private Node end = null;
    /**
     * Nombre d'élements dans la liste
     */
    private int size = 0;

    /**
     * Permet de construire une liste vide
     *
     */
    public SingleLinkedList() {
    }

    /***
     * Permet de construire une liste avec l'élement passé en paramètre
     * @param pVal
     */
    public SingleLinkedList(Object pVal) {
        Node temp = new Node(pVal);
        end = temp;
        begin = temp;
    }

    /**
     * Ajout d'un élément à la liste
     */
    public void addElement(Object pValue) {

        Node temp = new Node(pValue);
        //Si la liste est vide
        if (isEmpty()) {
            end = begin = temp;
        }
        else{
            end.setNext(temp);
            end = temp;
        }

        size++;

    }

    /**
     * retourner le premier élément de la liste
     */
    public Node getFirstElement() {
        return begin;
    }

    /**
     * retourner la taille de la liste
     */
    public int size() {

        return size;
    }

    /**
     * Indique si la liste est vide ou pas
     */
    public boolean isEmpty() {
        return begin == null;
    }

    /**
     * Supression d’un élément d’indice i
     */
    public boolean deleteElement(int index) {
        //Si la liste est vide ou si l'indice est hors de la liste
        if (isEmpty() || index >= size()) {
            return false;
        }
        //Cas de la Suppression au début
        if (index == 0) {
            Node temp = begin.getNext();
            begin.setNext(null);// Cette instruction est pour aider le GC
            begin = temp;
            size--;
            return true;
        }
        //Les autres cas
        int pos;
        Node p, q;
        for ( q = begin,p = begin.getNext(), pos = 1; pos < index ; pos++, p = p.getNext()) {
            q = p;
        }
        Node temp = p.getNext();
        p.setNext(null);// Cette instruction est pour aider le GC
        q.setNext(temp);
        size--;
        return true;
    }


    /**
     * Supression d’un élément passé en argument
     */
    public boolean deleteElement(Object pElement) {
        //Si la liste est vide
        if (isEmpty()) {
            return false;
        }
        //Cas de la suppresion au début
        if (begin.getValue().equals(pElement)) {
            Node temp = begin.getNext();
            begin.setNext(null);// Cette instruction est pour aider le GC
            begin = temp;
            size--;
            return true;
        }

        boolean deleted = false;
        for (Node p = begin.getNext(), q = begin;  p != null; p = p.getNext()) {
            if (p.getValue().equals(pElement)) {
                Node temp = p.getNext();
                p.setNext(null);// Cette instruction est pour aider le GC
                q.setNext(temp);
                deleted = true;
                break;
            }
            q = p;
        }
        return deleted;
    }


    public void display() {
        System.out.println("-----------------");
        if(isEmpty()){
            System.out.println("Lise vide");
        }
        for (Node p = begin, q = begin; p != null; p = p.getNext()) {
            System.out.println(p.getValue());
        }
    }

    public static void main(String[] args) {
        SingleLinkedList s = new SingleLinkedList();
        s.addElement(new Point(11, 2));
        s.addElement(new Point(1, 2));
        s.addElement(new Point(1, 21));

        s.display();

        s.deleteElement(new Point(1, 2));
        s.display();



    }

}
