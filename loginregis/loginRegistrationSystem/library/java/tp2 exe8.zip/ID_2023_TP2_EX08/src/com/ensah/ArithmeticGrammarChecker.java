package com.ensah;

public class ArithmeticGrammarChecker {
	public static boolean checkParenthesis(String expression) {

		Pile p = new Pile();

		for (int i = 0; i < expression.length(); i++) {
			if (expression.charAt(i) == '(') {
				p.empiler("(");
			} else if (expression.charAt(i) == ')') {

				if (p.estVide()) {
					// il y a plus de parenthéses fermantes que de
					// parenthéses ouvrantes
					return false;
				} else {
					p.depiler();
				}

			}
		}

		if (p.estVide()) {
			return true;
		}
		return false;

	}

	public static void main(String[] args) {

		if (ArithmeticGrammarChecker.checkParenthesis("a+b+(1*2)*(1+3)")) {
			System.out.println("Expression bien parenthésée");
		} else {
			System.out.println("Expression mal parenthésée");

		}

		if (ArithmeticGrammarChecker.checkParenthesis("(a+b+(1*2)*(1+3)")) {
			System.out.println("Expression bien parenthésée");
		} else {
			System.out.println("Expression mal parenthésée");

		}

		if (ArithmeticGrammarChecker.checkParenthesis("a+b+(1*2)*(1+3))")) {
			System.out.println("Expression bien parenthésée");
		} else {
			System.out.println("Expression mal parenthésée");

		}

		if (ArithmeticGrammarChecker.checkParenthesis("a+b+(1*2)*(1+3)+(")) {
			System.out.println("Expression bien parenthésée");
		} else {
			System.out.println("Expression mal parenthésée");

		}
		if (ArithmeticGrammarChecker.checkParenthesis("((a+b+(1*2)*(1+3)+()))+(((1+a)*3)+5)")) {
			System.out.println("Expression bien parenthésée");
		} else {
			System.out.println("Expression mal parenthésée");

		}
	}
}
