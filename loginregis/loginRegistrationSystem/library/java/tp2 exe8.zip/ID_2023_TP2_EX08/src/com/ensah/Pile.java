package com.ensah;

import java.util.ArrayList;

/**
 * Pile  implémentée avec ArrayList
 * 
 * @author Tarik BOUDAA
 *
 */
public class Pile {

	/** Tableau pour contenir les objets de la pile */
	private ArrayList<Object> data;

	/**
	 * Construit une pile vide
	 * 
	 */
	public Pile() {

		data = new ArrayList<>();
	}

	/**
	 * Permet de vérifier si la pile est vide
	 * 
	 * @return true si la pile est vide et false sinon
	 */
	public boolean estVide() {
		return data == null || data.size() == 0;
	}

	/**
	 * Ajoute un élément au sommet de la pile
	 * 
	 * @param o objet à empiler
	 * 
	 */
	public void empiler(Object o) {

		data.add(o);

	}

	/**
	 * Permet de supprimer un élément du sommet de la pile
	 * 
	 * @return le sommet de la pile si la pile n'est pas vide et null sinon
	 */
	public Object depiler() {

		// Si la pile est vide
		if (estVide()) {
			return null;
		}


		// On supprime et on retourne le sommet
		return data.remove(data.size() - 1);

	}

	/**
	 * Retourne le sommet ou null si la pile est vide
	 * 
	 * @return le sommet ou null
	 */
	public Object getSommet() {
		if (!estVide()) {
			return data.get(data.size() - 1);
		}
		return null;
	}

	/**
	 * Afficher le contenu de la pile
	 */
	public void affiche() {

		System.out.println("======Contenu de la pile=======");

		if (estVide()) {

			// On affiche un message
			System.out.println("La pile est vide");

			// fin de la méthode
			return;
		}

		// Afficher la pile de telle sorte que le sommet soit en haut
		for (int i = data.size() - 1; i >= 0; i--) {
			System.out.println(data.get(i));
		}
	}

}
