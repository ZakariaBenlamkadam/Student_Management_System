package com.ensah;

public class TestPile {
	public static void main(String[] args) {

		Pile  p = new Pile();
		p.empiler(1);
		p.empiler(2);
		p.empiler(3);
		p.empiler(4);
		p.affiche();
		Integer  i = (Integer) p.depiler();
		System.out.println("sommet ="+i);
		p.affiche();
	}
}
