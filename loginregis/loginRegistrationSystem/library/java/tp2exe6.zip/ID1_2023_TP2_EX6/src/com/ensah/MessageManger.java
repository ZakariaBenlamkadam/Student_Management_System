package com.ensah;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Cette classe permet de gerer les message
 * 
 * @author boudaa
 *
 */
public class MessageManger {

	/** permet de stocker les messages */
	private List<Message> messages = new LinkedList<Message>();

	/**
	 * cette methode permet de supprime un messsage avec son identifiant
	 * 
	 * @param id identifiant du message
	 * @return retourne l'etat de succes ou non de cette methode
	 */
	public boolean deleteMessage(int id) {

		// Si la liste est vide
		if (isVide()) {
			return false;
		}

		boolean found = false;
		int i = 0;
		// rechercher le message avec l'identifiant passe en parametre
		for (i = 0; i < messages.size(); i++) {

			if (messages.get(i).getId() == id) {
				found = true;
				break;
			}

		}

		if (found) {
			messages.remove(i);

		}

		return found;

	}

	private boolean isVide() {
		return messages == null || messages.size() == 0;
	}

	/**
	 * Retourne le premier element dans la liste ou null si la list est vide
	 * 
	 * @return
	 */
	public Message getFirstMessage() {

		if (isVide()) {
			return null;
		}

		return messages.get(0);
	}

	/**
	 * Retourne le dernier element dans la liste ou null si la liste est vide
	 * 
	 * @return
	 */
	public Message getLastMessage() {
		if (isVide()) {
			return null;
		}
		return messages.get(messages.size() - 1);
	}

	/**
	 * Rechercher un element par son identifiant
	 * 
	 * @param id
	 * @return
	 */
	public Message findMessageById(int id) {

		for (Message it : messages) {

			if (it.getId() == id)
				return it;
		}

		return null;
	}

	/**
	 * Mettre e jour un message par les donnees passees dans l'objet en parametre
	 * 
	 * @param m
	 * @return
	 */
	public boolean updateMessage(Message m) {

		Message msg = findMessageById(m.getId());

		if (msg != null) {
			msg.setContenu(m.getContenu());
			msg.setDate(m.getDate());
			msg.setTitre(m.getTitre());

			return true;

		}

		return false;

	}

	/**
	 * Recherche un message par son titre
	 * 
	 * @param pTitre
	 * @return
	 */
	public List<Message> findMessageByTitle(String pTitre) {
		List<Message> searchResult = new ArrayList<Message>();
		for (Message it : messages) {
			if (it.getTitre().equals(pTitre))
				searchResult.add(it);
		}

		return searchResult;
	}

	/**
	 * Affiche tous les messages de la liste
	 */
	public void display() {

		System.out.println("-----Contenu de la liste-----");
		for (Message it : messages) {
			System.out.println(it.toString());
		}

	}

	public void displaySearchResult(List<Message> results) {
		System.out.println("Resultat de recherche :");
		if (results.size() == 0) {
			System.out.println("Il n y a aucun element qui correspond à votre recherche");
		} else {
			for (Message it : results) {
				System.out.println(it);
			}
		}
	}

	/**
	 * Ajoute un message dans la liste des messages
	 * 
	 * @param m
	 */
	public void dddMessage(Message m) {

		messages.add(m);
	}

	/**
	 * Retourne tous les messages
	 * 
	 * @return
	 */
	public List<Message> getAllMessages() {

		return messages;

	}

}
