package com.ensah;

public class Entrepot {

	/** pile qui sert à stocker l'ensemble des produits */
	private PileProduitAvecArrayList pileProduit;

	/**
	 * Constructeur
	 */
	public Entrepot() {
		pileProduit = new PileProduitAvecArrayList();
	}

	/**
	 * Supprime les produits perimes et calcule la somme des pertes (somme de leurs
	 * prix)
	 * 
	 * @return
	 */
	public double suppressionPerime() {

		double somme = 0.0;
		// On tri la pile de telle sorte que les produits ayant le plus petit nbr jour
		// avant
		// peremption soient en tete de la pile
		pileProduit.tri();

		// Il suffit maintenant de depiler les produits ayant nbrJourAvantPer = 0
		while (pileProduit.getSommet().getNbrJourAvantPer() == 0) {

			// depiler et compter la somme des prix des produits depiles
			somme += pileProduit.depiler().getPrix();
		}
		return somme;
	}

	/**
	 * Permet d'ajouter un produit dans l'entrepot
	 * 
	 * @param p
	 */
	public void addProduit(Produit p) {
		pileProduit.empiler(p);
	}

	/**
	 * Permet d'afficher les produits de l'entrepot
	 */
	public void afficheEntrepot() {
		System.out.println("---------- Affichage du contenu de l'entrepot --------------");
		pileProduit.affiche();
	}
}
