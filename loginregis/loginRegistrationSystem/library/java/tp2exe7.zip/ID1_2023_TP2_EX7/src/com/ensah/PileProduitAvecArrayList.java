package com.ensah;

import java.util.ArrayList;

/**
 * Pile de produits implementee avec ArrayList
 * 
 * @author Tarik BOUDAA
 *
 */
public class PileProduitAvecArrayList {

	/** Tableau pour contenir les produits */
	private ArrayList<Produit> data;

	/**
	 * Construit une pile de produit vide
	 * 
	 */
	public PileProduitAvecArrayList() {
		// Construction de l'objet tableau des produits
		data = new ArrayList<>();
	}

	/**
	 * Permet de verifier si la pile est vide
	 * 
	 * @return true si la pile est vide et false sinon
	 */
	public boolean estVide() {
		return data == null || data.size() == 0;
	}

	/**
	 * Ajoute un element au sommet de la pile
	 * 
	 * @param p produit e empiler
	 * 
	 */
	public void empiler(Produit p) {

		data.add(p);

	}

	/**
	 * Permet de supprimer un element du sommet de la pile
	 * 
	 * @return le sommet de la pile si la pile n'est pas vide et null sinon
	 */
	public Produit depiler() {

		// Si la pile est vide
		if (estVide()) {
			return null;
		}

		// On garde le produit qui se trouve au sommet dans une variable temporaire
		Produit temp = getSommet();

		// On supprime le dernier element
		data.remove(data.size() - 1);

		// On retourne le sommet
		return temp;

	}

	/**
	 * Retourne le sommet ou null si la pile est vide
	 * 
	 * @return le sommet ou null
	 */
	public Produit getSommet() {
		if (!estVide()) {
			return data.get(data.size() - 1);
		}
		return null;
	}

	/**
	 * Afficher le contenu de la pile
	 */
	public void affiche() {

		System.out.println("======Contenu de la pile=======");

		if (estVide()) {

			// On affiche un message
			System.out.println("La pile est vide");

			// fin de la methode
			return;
		}

		// Afficher la pile de telle sorte que le sommet soit en haut
		for (int i = data.size() - 1; i >= 0; i--) {
			System.out.println(data.get(i));
		}
	}

	/**
	 * Tri avec l'algorithme de selection de l'optimum
	 */
	public void tri() {
		// On declare une variable qui va contenir l'index du maximum
		int indexMax;

		// Parcourir le tableau
		for (int i = 0; i < data.size() - 1; i++) {

			indexMax = i;
			// Chercher si il y a un produit ayant nbrJourPer plus grand que ce lui du
			// produit e la
			// position indexMax. Si oui changer la valeur de indexMax
			for (int j = i + 1; j < data.size(); j++) {
				if (data.get(j).getNbrJourAvantPer() > data.get(indexMax).getNbrJourAvantPer()) {
					indexMax = j;
				}
			}

			// Faire un echange entre le produit e la position i et celui en indexMax
			if (indexMax != i) {
				Produit aide = data.get(i);
				data.set(i, data.get(indexMax));
				data.set(indexMax, aide);

			}

		}
	}

}
