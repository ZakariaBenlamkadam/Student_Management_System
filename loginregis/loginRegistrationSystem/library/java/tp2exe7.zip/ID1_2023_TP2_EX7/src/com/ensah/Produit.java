package com.ensah;

public class Produit {

	private String nom;

	private double prix;

	private int nbrJourAvantPer;

	public Produit() {
	}

	public Produit(String nom, double prix, int nbrJourAvantPer) {
		this.nom = nom;
		this.prix = prix;
		this.nbrJourAvantPer = nbrJourAvantPer;
	}

	public int compare(Produit p) {
		return this.nbrJourAvantPer - p.nbrJourAvantPer;
	}

	@Override
	public String toString() {
		return "Produit [nom=" + nom + ", prix=" + prix + ", nbrJourAvantPer=" + nbrJourAvantPer + "]";
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}

	public int getNbrJourAvantPer() {
		return nbrJourAvantPer;
	}

	public void setNbrJourAvantPer(int nbrJourAvantPer) {
		this.nbrJourAvantPer = nbrJourAvantPer;
	}

}
