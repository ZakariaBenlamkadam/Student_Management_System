package com.ensah;

public class TestPileAvecTableau {
	public static void main(String[] args) {

		// Creation des produits
		Produit p1 = new Produit("Produit1", 500, 51);
		Produit p2 = new Produit("Produit2", 600, 0);
		Produit p3 = new Produit("Produit3", 700, 70);
		Produit p4 = new Produit("Produit4", 256, 0);
		Produit p5 = new Produit("Produit5", 200, 60);
		Produit p6 = new Produit("Produit5", 111, 63);

		// Creation d'une pile de produits (Version avec Tableau)
		PileProduitArrayVersionAmelioree pileProduit = new PileProduitArrayVersionAmelioree();

		// On empile des produits
		pileProduit.empiler(p1);
		pileProduit.empiler(p2);
		pileProduit.empiler(p3);
		pileProduit.empiler(p4);
		pileProduit.empiler(p5);
		pileProduit.empiler(p6);

		// Afficher le contenu de la pile
		pileProduit.affiche();

		// On depile
		pileProduit.depiler();

		// On reaffiche
		pileProduit.affiche();

		// Trier la pile
		pileProduit.tri();

		// On reaffiche
		System.out.println(" ****** Apres le tri *******");
		pileProduit.affiche();

		// Creation de l'objet Entrepot
		Entrepot en = new Entrepot();

		// On y ajoute des produits (ils seront ajoutes dans sa pile)
		en.addProduit(p5);
		en.addProduit(p2);
		en.addProduit(p3);
		en.addProduit(p4);
		en.addProduit(p1);
		en.addProduit(p6);

		// On affiche le contenu de l'entrepot
		en.afficheEntrepot();

		// On supprime les produit perimes et on calcule la somme des prix
		double somme = en.suppressionPerime();

		System.out.println("\tSomme des pertes =" + somme);

		// On reaffiche l'entrepot
		en.afficheEntrepot();

	}
}
